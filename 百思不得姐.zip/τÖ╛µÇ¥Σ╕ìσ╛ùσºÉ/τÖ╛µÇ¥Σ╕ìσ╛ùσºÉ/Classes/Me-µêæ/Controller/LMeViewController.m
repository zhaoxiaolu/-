//
//  LMeViewController.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/16.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "LMeViewController.h"

@interface LMeViewController ()

@end

@implementation LMeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeInterface];
}

- (void)initializeInterface{
    self.navigationItem.rightBarButtonItems = @[
                                                [UIBarButtonItem itemWithImage:@"mine-setting-icon" HeightImage:@"mine-setting-icon-click" Target:self action:@selector(setttingClick:)],
                                                [UIBarButtonItem itemWithImage:@"mine-moon-icon" HeightImage:@"mine-moon-icon-click" Target:self action:@selector(moonNightClick:)]
                                                ];
    self.view.backgroundColor = LColor(223, 223, 223, 1);

}

- (void)setttingClick:(UIButton *)sender{
    FuncLog;
}

- (void)moonNightClick:(UIButton *)sender{
    FuncLog;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
