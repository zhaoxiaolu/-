//
//  RecommendModel.h
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/27.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RecommendModel : NSObject

/** id*/
@property(nonatomic, assign) NSInteger id;
/** name*/
@property(nonatomic, copy) NSString * name;
/** count*/
@property(nonatomic, assign) NSInteger count;

/** 这个类别对应的数据，这里的可变数组不能用copy修饰*/
@property(nonatomic, strong) NSMutableArray * listArrays;

/** 有多少数据*/
@property(nonatomic, assign) NSInteger total;
/** 当前页码（自己写的）*/
@property(nonatomic, assign) NSInteger currentPage;

/** 总页数*/
//@property(nonatomic, assign) NSInteger total_page;
/** 下一页的页数*/
//@property(nonatomic, assign) NSInteger next_page;


/** 字典转模型方法*/
+ (NSArray *)modelDataSourceWithDataArray:(NSArray *)dataArray;
@end
