//
//  RecommendDetailModel.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "RecommendDetailModel.h"

@implementation RecommendDetailModel
/**
 *  防止崩溃
 */
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}



+ (NSArray *)modelDataSourceWithDataArray:(NSArray *)dataArray{
    NSMutableArray *result = [[NSMutableArray alloc]init];
    for (NSInteger index = 0; index < dataArray.count; index ++) {
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:dataArray[index]];
        RecommendDetailModel *model = [[RecommendDetailModel alloc]init];
        [model setValuesForKeysWithDictionary:dic];
        [result addObject:model];
    }
    return result;
}


@end
