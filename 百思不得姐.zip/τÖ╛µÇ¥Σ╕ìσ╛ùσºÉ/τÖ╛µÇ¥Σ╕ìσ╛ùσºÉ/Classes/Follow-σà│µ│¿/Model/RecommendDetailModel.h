//
//  RecommendDetailModel.h
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RecommendDetailModel : NSObject
/** 头像url*/
@property(nonatomic, copy) NSString * header;
/** 粉丝数量*/
@property(nonatomic, assign) NSInteger fans_count;
/** 昵称*/
@property(nonatomic, copy) NSString * screen_name;

+ (NSArray *)modelDataSourceWithDataArray:(NSArray *)dataArray;
@end
