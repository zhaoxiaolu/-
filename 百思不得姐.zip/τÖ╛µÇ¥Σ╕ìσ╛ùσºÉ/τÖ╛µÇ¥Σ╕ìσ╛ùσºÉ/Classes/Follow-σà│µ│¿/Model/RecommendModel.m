//
//  RecommendModel.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/27.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "RecommendModel.h"

@implementation RecommendModel

/**
 *  防止崩溃
 */
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}


+ (NSArray *)modelDataSourceWithDataArray:(NSArray *)dataArray{
    NSMutableArray *result = [[NSMutableArray alloc]init];
    for (NSInteger index = 0; index < dataArray.count; index ++) {
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:dataArray[index]];
        RecommendModel *model = [[RecommendModel alloc]init];
        [model setValuesForKeysWithDictionary:dic];
        [result addObject:model];
    }
    return result;
}

#pragma mark - getter
- (NSMutableArray *)listArrays{
    if (!_listArrays) {
        _listArrays = [NSMutableArray array];
    }
    return _listArrays;
}

@end
