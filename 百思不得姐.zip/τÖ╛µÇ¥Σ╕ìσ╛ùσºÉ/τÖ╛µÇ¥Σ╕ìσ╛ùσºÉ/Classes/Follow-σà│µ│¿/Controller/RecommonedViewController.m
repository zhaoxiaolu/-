//
//  RecommonedViewController.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "RecommonedViewController.h"

#import "RecommendTableViewCell.h"
#import "RecommendModel.h"

#import "RecommendDetailTableViewCell.h"
#import "RecommendDetailModel.h"


#define listTableViewCellIdentifier @"listTableViewCellIdentifier"
#define detailTableViewCellIdentifier @"detail"


@interface RecommonedViewController ()<UITableViewDelegate,UITableViewDataSource>
/** 分类列表*/
@property(nonatomic, strong) UITableView * listTableView;
/** 分类详情列表*/
@property(nonatomic, strong) UITableView * detailTableView;
/** 分类列表数据源*/
@property(nonatomic, strong) NSMutableArray * listDataSource;
@end

@implementation RecommonedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeInterface];
    [self initializeDataSource];
}

- (void)initializeInterface{
    self.navigationItem.title = @"推荐关注";
    self.view.backgroundColor = LColor(223, 223, 223, 1);
    [self setupRefresh];
    
    /** 初始化数据源*/
    self.listDataSource = [NSMutableArray array];
    
    [self.view addSubview:self.listTableView];
    [self.view addSubview:self.detailTableView];
    
    [self.listTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.left.mas_equalTo(self.view);
        make.width.equalTo(@50);
    }];
    
    [self.detailTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.bottom.and.right.equalTo(self.view);
        make.left.equalTo(self.listTableView.mas_right);
    }];
}


- (void)initializeDataSource{
    [SVProgressHUD show];
    NSMutableDictionary *paramsDic = [NSMutableDictionary dictionary];
    paramsDic[@"a"] = @"category";
    paramsDic[@"c"] = @"subscribe";
    [RequestNet requestNet:@"http://api.budejie.com/api/api_open.php" paramsDic:paramsDic requestType:GETRequest successHandle:^(id object, BOOL isSuccess) {
        if (isSuccess) {
            [SVProgressHUD dismiss];
            
            /** 字典数组 —> 模型数组*/
            NSArray *listArray = [RecommendModel modelDataSourceWithDataArray:object[@"list"]];
            
            [self.listDataSource addObjectsFromArray:listArray];
            
            /** 刷新表格*/
            [self.listTableView reloadData];
            /** 刷新表格后，默认选中首行*/
            [self.listTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];
        }else{
            [SVProgressHUD showErrorWithStatus:@"加载失败!"];
        }
    }];
}


/**
 * 添加刷新控件
 */
- (void)setupRefresh{
    self.detailTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewDetail)];
    
    self.detailTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDetail)];
    self.detailTableView.mj_footer.hidden = YES;
}


/**
 * 下拉刷新右边表格的数据
 */
- (void)loadNewDetail{
    /** 左边分类列表被选中的模型*/
    RecommendModel *model = self.listDataSource[self.listTableView.indexPathForSelectedRow.row];
    
    /** 设置当前页码为1*/
    model.currentPage = 1;
    
    /** 右边表格没有曾经的数据，需要加载网络请求*/
    [RequestNet requestNet:@"http://api.budejie.com/api/api_open.php"
                 paramsDic:@{
                             @"a":@"list",
                             @"c":@"subscribe",
                             @"category_id":@(model.id),
                             @"pagesize":@(10),
                             @"page":@(model.currentPage)
                             }
               requestType:GETRequest
             successHandle:^(id object, BOOL isSuccess) {
                 if (isSuccess) {
                     /** 为避免下拉刷新重复添加，应先清除以前的所有数据*/
                     [model.listArrays removeAllObjects];
                     
                     /** 保存返回的数据总数*/
                     model.total = [object[@"total"] integerValue];
                     
                     /** 字典数组->模型数组*/
                     NSArray *dataArray = [RecommendDetailModel modelDataSourceWithDataArray:object[@"list"]];
                     
                     /** 添加到当前类别的对应的数组中*/
                     [model.listArrays addObjectsFromArray:dataArray];
                     
                     /** 刷新右边的详情表格*/
                     [self.detailTableView reloadData];
                     
                     /** 结束下拉刷新*/
                     [self.detailTableView.mj_header endRefreshing];
                     
                     /** 时刻监测footer的加载状态*/
                     [self checkFooterStatus];
                     
                 }else{
                     /** 加载失败提醒*/
                     [SVProgressHUD showErrorWithStatus:@"下拉加载数据失败"];
                     
                     /** 结束下拉刷新*/
                     [self.detailTableView.mj_header endRefreshing];
                 }
             }];
}


/**
 * 上拉加载右边表格的更多数据
 */
- (void)loadMoreDetail{
    /** 左边分类列表被选中的模型*/
    RecommendModel *model = self.listDataSource[self.listTableView.indexPathForSelectedRow.row];
    
    /** 当前页码加1*/
    ++ model.currentPage;
    
    /** 右边表格没有曾经的数据，需要加载网络请求*/
    [RequestNet requestNet:@"http://api.budejie.com/api/api_open.php"
                 paramsDic:@{
                             @"a":@"list",
                             @"c":@"subscribe",
                             @"category_id":@(model.id),
                             @"pagesize":@(10),
                             @"page":@(model.currentPage)
                             }
               requestType:GETRequest
             successHandle:^(id object, BOOL isSuccess) {
                 if (isSuccess) {
                     
                     /** 字典数组->模型数组*/
                     NSArray *dataArray = [RecommendDetailModel modelDataSourceWithDataArray:object[@"list"]];
                     
                     /** 添加到当前类别的对应的数组中*/
                     [model.listArrays addObjectsFromArray:dataArray];
                     
                     /** 刷新详情表格*/
                     [self.detailTableView reloadData];
                     
                     /** 时刻监测footer的加载状态*/
                     [self checkFooterStatus];
                     
                 }else{
                     /** 加载失败提醒*/
                     [SVProgressHUD showErrorWithStatus:@"上拉加载数据失败"];
                     /** 结束刷新*/
                     [self.detailTableView.mj_footer endRefreshing];
                 }
             }];
}


/**
 * 时刻监测footer的加载状态
 */
- (void)checkFooterStatus{
    /** 左边分类列表被选中的模型*/
    RecommendModel *model = self.listDataSource[self.listTableView.indexPathForSelectedRow.row];
    
    /** 当数据为0时隐藏*/
    self.detailTableView.mj_footer.hidden = ((self.listDataSource[self.listTableView.indexPathForSelectedRow.row]) == 0);
    
    if (model.listArrays.count == model.total) {//全部数据已加载完毕
        /** 全部数据已加载完毕，停止加载*/
        [self.detailTableView.mj_footer endRefreshingWithNoMoreData];
    }else{
        /** 结束刷新*/
        [self.detailTableView.mj_footer endRefreshing];
    }
}


#pragma mark - UITableViewDelegate,UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == self.listTableView) {
        return self.listDataSource.count;
    }else{
        /** 判断是否为第一次进来，如果self.listTableView.indexPathForSelectedRow.row不为空*/
        if (self.listTableView.indexPathForSelectedRow.row) {
            /** 左边分类列表被选中的模型*/
            RecommendModel *model = self.listDataSource[self.listTableView.indexPathForSelectedRow.row];
            
            /** 时刻监测footer的加载状态*/
            [self checkFooterStatus];
            
            return model.listArrays.count;
        }else{
            self.detailTableView.mj_footer.hidden = YES;
            return 0;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == self.listTableView) {
        RecommendTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:listTableViewCellIdentifier];
        cell.model = self.listDataSource[indexPath.row];
        
        return cell;
    }else{
        RecommendDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:detailTableViewCellIdentifier];
        
        /** 左边分类列表被选中的模型*/
        RecommendModel *model = self.listDataSource[self.listTableView.indexPathForSelectedRow.row];
        
        cell.model = model.listArrays[indexPath.row];
        
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    /** 判断tableView的类型*/
    if (tableView == self.listTableView) {
        
        /** 左边的分类列表模型*/
        RecommendModel *model = self.listDataSource[indexPath.row];
        
        if (model.listArrays.count) {
            /** 右边表格有曾经的数据，不用加载再网络请求，直接刷新表格*/
            [self.detailTableView reloadData];
        }else{
            /** 刷新表格，马上显示当前点击的detailTableView表格的数据，避免用户看见上一个detailTableView表格的数据*/
            [self.detailTableView reloadData];
            
            /** 开始下拉刷新*/
            [self.detailTableView.mj_header beginRefreshing];
            
        }
    }
}



#pragma mark - getter
- (UITableView *)listTableView{
    if (!_listTableView) {
        _listTableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _listTableView.backgroundColor = LColor(244, 244, 244, 1);
        _listTableView.delegate = self;
        _listTableView.dataSource = self;
        [_listTableView registerClass:[RecommendTableViewCell class] forCellReuseIdentifier:listTableViewCellIdentifier];
        _listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _listTableView;
}

- (UITableView *)detailTableView{
    if (!_detailTableView) {
        _detailTableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _detailTableView.delegate = self;
        _detailTableView.dataSource = self;
        [_detailTableView registerNib:[UINib nibWithNibName:NSStringFromClass([RecommendDetailTableViewCell class]) bundle:nil] forCellReuseIdentifier:detailTableViewCellIdentifier];
        _detailTableView.tableFooterView = [UIView new];
        _detailTableView.rowHeight = 65.f;
    }
    return _detailTableView;
}


#pragma mark - system
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
