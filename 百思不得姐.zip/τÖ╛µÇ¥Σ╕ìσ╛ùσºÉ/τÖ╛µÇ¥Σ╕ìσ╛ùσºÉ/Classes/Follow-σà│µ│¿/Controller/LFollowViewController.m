//
//  LFollowViewController.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/16.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "LFollowViewController.h"
#import "RecommonedViewController.h"


@interface LFollowViewController ()

@end

@implementation LFollowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initiazeInterface];
}


- (void)initiazeInterface{
    /** 只修改导航栏标题*/
    self.navigationItem.title = @"我的关注";
    
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithImage:@"friendsRecommentIcon" HeightImage:@"friendsRecommentIcon-click" Target:self action:@selector(friendsClick:)];
    self.view.backgroundColor = LColor(223, 223, 223, 1);
}


- (void)friendsClick:(UIButton *)sender{
    RecommonedViewController *vc = [[RecommonedViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - system
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
