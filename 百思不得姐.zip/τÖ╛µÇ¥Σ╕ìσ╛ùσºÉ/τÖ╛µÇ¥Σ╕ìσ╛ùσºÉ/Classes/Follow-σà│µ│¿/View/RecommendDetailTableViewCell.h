//
//  RecommendDetailTableViewCell.h
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RecommendDetailModel;

@interface RecommendDetailTableViewCell : UITableViewCell
/** 模型*/
@property(nonatomic, strong) RecommendDetailModel * model;
@end
