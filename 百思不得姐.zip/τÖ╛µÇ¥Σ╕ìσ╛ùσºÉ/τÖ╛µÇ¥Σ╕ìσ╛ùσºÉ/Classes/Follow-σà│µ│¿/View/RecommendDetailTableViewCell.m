//
//  RecommendDetailTableViewCell.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "RecommendDetailTableViewCell.h"
#import "RecommendDetailModel.h"

@interface RecommendDetailTableViewCell ()
/** 头像*/
@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
/** 昵称*/
@property (weak, nonatomic) IBOutlet UILabel *screenNameLabel;
/** 粉丝数*/
@property (weak, nonatomic) IBOutlet UILabel *fansCountLabel;

@end

@implementation RecommendDetailTableViewCell


- (void)setModel:(RecommendDetailModel *)model{
    
    _model = model;
    
    self.screenNameLabel.text = model.screen_name;
    self.fansCountLabel.text = [NSString stringWithFormat:@"%zd人关注",model.fans_count];
    [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:model.header] placeholderImage:[UIImage imageNamed:@"defaultUserIcon"]];
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
