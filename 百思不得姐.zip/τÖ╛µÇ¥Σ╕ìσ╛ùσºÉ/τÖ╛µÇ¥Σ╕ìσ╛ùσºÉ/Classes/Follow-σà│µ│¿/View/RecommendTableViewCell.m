//
//  RecommendTableViewCell.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "RecommendTableViewCell.h"
#import "RecommendModel.h"

@interface RecommendTableViewCell ()
/** 白色分割线*/
@property(nonatomic, strong) UIView * lineView;
/** 选中标记*/
@property(nonatomic, strong) UIView * selectedView;
@end

@implementation RecommendTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeInterface];
    }
    return self;
}

- (void)initializeInterface{
    self.backgroundColor = LColor(244, 244, 244, 1);
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    [self.contentView addSubview:self.titleLabel];
    [self.contentView addSubview:self.lineView];
    [self.contentView addSubview:self.selectedView];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.contentView).with.insets(UIEdgeInsetsMake(1, 10, 1, 10));
    }];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.and.left.and.right.equalTo(self.contentView);
        make.height.equalTo(@1);
    }];
    
    [self.selectedView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.bottom.and.left.equalTo(self.contentView);
        make.width.equalTo(@5);
    }];
}

#pragma mark - setter
- (void)setModel:(RecommendModel *)model{
    _model = model;
    self.titleLabel.text = model.name;
}

#pragma mark - getter
- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.font = [UIFont systemFontOfSize:10];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        
        /** 当设置cell的selectionStyle为UITableViewCellSelectionStyleNone，即使cell被选中，cell内部的所有子控件都不会进入高亮状态*/
//        _titleLabel.textColor = LColor(78, 78, 78, 1);
//        _titleLabel.highlightedTextColor = LColor(219, 21, 26, 1);
    }
    return _titleLabel;
}

- (UIView *)lineView{
    if (!_lineView) {
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = [UIColor whiteColor];
    }
    return _lineView;
}

- (UIView *)selectedView{
    if (!_selectedView) {
        _selectedView = [[UIView alloc]init];
        _selectedView.backgroundColor = LColor(219, 21, 26, 1);
    }
    return _selectedView;
}

#pragma mark - system
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

/** 可以在这个方法中，监听cell的选中和取消选中*/
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    /** 设置是否选中*/
    self.selectedView.hidden = !selected;
    /** 设置选中是的字体颜色*/
    self.titleLabel.textColor = selected ? LColor(219, 21, 26, 1) : LColor(78, 78, 78, 1);
}

@end
