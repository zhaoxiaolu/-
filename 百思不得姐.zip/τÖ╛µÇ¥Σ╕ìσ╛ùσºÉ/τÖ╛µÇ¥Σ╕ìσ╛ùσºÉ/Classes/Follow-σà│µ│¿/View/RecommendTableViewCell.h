//
//  RecommendTableViewCell.h
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RecommendModel;

@interface RecommendTableViewCell : UITableViewCell
/** 标题*/
@property(nonatomic, strong) UILabel * titleLabel;
/** 模型*/
@property(nonatomic, strong) RecommendModel * model;
@end
