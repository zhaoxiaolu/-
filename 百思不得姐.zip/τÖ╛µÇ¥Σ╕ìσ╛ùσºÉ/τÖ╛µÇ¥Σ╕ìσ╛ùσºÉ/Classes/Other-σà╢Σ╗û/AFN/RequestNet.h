//
//  RequestNet.h
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^successHandle)(id object, BOOL isSuccess);

typedef enum : NSUInteger {
    GETRequest,
    POSTRequest
} RequestType;


@interface RequestNet : NSObject
+ (void)requestNet:(NSString *)url
         paramsDic:(NSDictionary *)paramsDic
       requestType:(RequestType)requestType
     successHandle:(successHandle)successHandle;
@end
