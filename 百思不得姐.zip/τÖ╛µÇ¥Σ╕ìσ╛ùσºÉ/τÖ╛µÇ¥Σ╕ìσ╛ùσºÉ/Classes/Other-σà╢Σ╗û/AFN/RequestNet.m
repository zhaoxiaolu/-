//
//  RequestNet.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/26.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "RequestNet.h"
#import <AFNetworking.h>


@implementation RequestNet
+ (void)requestNet:(NSString *)url paramsDic:(NSDictionary *)paramsDic requestType:(RequestType)requestType successHandle:(successHandle)successHandle{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer.timeoutInterval = 10.f;
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json",@"text/html",@"text/javascript", nil];
    
    switch (requestType) {
        case GETRequest:
        {
            [manager GET:url parameters:paramsDic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                if (successHandle) {
                    successHandle(responseObject,1);
                }
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                if (successHandle) {
                    successHandle(error,0);
                }
            }];
        }
            break;
            
        case POSTRequest:
        {
            [manager POST:url parameters:paramsDic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                if (successHandle) {
                    successHandle(responseObject,1);
                }
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                if (successHandle) {
                    successHandle(error,0);
                }
            }];
        }
            break;
    }
}
@end
