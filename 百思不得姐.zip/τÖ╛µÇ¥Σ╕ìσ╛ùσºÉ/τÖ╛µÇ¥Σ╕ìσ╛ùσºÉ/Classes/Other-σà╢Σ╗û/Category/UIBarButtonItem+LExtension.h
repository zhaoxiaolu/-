//
//  UIBarButtonItem+LExtension.h
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/19.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (LExtension)
+ (instancetype)itemWithImage:(NSString *)image HeightImage:(NSString *)heightImage Target:(id)target action:(SEL)action;
@end
