//
//  UIBarButtonItem+LExtension.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/19.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "UIBarButtonItem+LExtension.h"

@implementation UIBarButtonItem (LExtension)

+ (instancetype)itemWithImage:(NSString *)image HeightImage:(NSString *)heightImage Target:(id)target action:(SEL)action{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:heightImage] forState:UIControlStateHighlighted];
    [button sizeToFit];
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return [[self alloc]initWithCustomView:button];
}


@end
