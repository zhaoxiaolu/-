//
//  LTabBar.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/16.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "LTabBar.h"

@interface LTabBar ()
/** 中间的加号按钮*/
@property(nonatomic, strong) UIButton * plusButton;
@end

@implementation LTabBar

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initializeInterface];
    }
    return self;
}


- (void)initializeInterface{
    self.backgroundImage = [UIImage imageNamed:@"tabbar-light"];
    /** 设置*/
    self.plusButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.plusButton setImage:[UIImage imageNamed:@"tabBar_publish_icon"] forState:UIControlStateNormal];
    [self.plusButton setImage:[UIImage imageNamed:@"tabBar_publish_click_icon"] forState:UIControlStateSelected];
    
    [self addSubview:self.plusButton];
    
    /** 设置tabBar是否为半透明*/
    self.translucent = NO;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    /**** 设置所有UITabBarButton的frame ****/
    // UITabBarButton按钮的尺寸
    CGFloat buttonWidth = self.frame.size.width/5;
    CGFloat buttonHeight = self.frame.size.height;
    CGFloat buttonY = 0;
    
    int buttonIndex = 0;
    for (UIView *subView in self.subviews) {
        
        if (subView.class != NSClassFromString(@"UITabBarButton")) continue;
        
        CGFloat buttonX = buttonIndex * buttonWidth;
        
        //设置右边的两个button
        if (buttonIndex >= 2) {
            buttonX += buttonWidth;
        }
        subView.frame = CGRectMake(buttonX, buttonY, buttonWidth, buttonHeight);
        buttonIndex ++;
    }
    
    self.plusButton.frame = CGRectMake(0, 0, buttonWidth, buttonHeight);
    self.plusButton.center = CGPointMake(self.frame.size.width*0.5, buttonHeight*0.5);
}

@end
