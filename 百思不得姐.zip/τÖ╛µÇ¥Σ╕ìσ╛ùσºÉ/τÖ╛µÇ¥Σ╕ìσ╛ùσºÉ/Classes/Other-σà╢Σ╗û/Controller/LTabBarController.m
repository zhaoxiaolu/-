//
//  LTabBarController.m
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/16.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import "LTabBarController.h"
#import "LTabBar.h"
#import "LNavigationController.h"

#import "LEssenceViewController.h"
#import "LNewViewController.h"
#import "LFollowViewController.h"
#import "LMeViewController.h"


@interface LTabBarController ()

@end

@implementation LTabBarController


/** 当第一次使用这个类的时候，会调用一次*/
+ (void)initialize{
    
    /***********************通过appearance统一设置所有UITabBarItem的属性**************************/
    /************后面带有UI_APPEARANCE_SELECTOR的方法，都可以通过appearance对象来统一设置*************/
    
    /** 设置未选中的标签字体属性*/
    NSMutableDictionary *attrsDic = [NSMutableDictionary dictionary];
    attrsDic[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    attrsDic[NSForegroundColorAttributeName] = [UIColor grayColor];
    
    /** 设置选中的标签字体属性*/
    NSMutableDictionary *selectedAttrsDic = [NSMutableDictionary dictionary];
    selectedAttrsDic[NSFontAttributeName] = attrsDic[NSFontAttributeName];
    selectedAttrsDic[NSForegroundColorAttributeName] = [UIColor darkGrayColor];
    
    /** 设置所有的tabBarItem属性都一样*/
    UITabBarItem *item = [UITabBarItem appearance];
    [item setTitleTextAttributes:attrsDic forState:UIControlStateNormal];
    [item setTitleTextAttributes:selectedAttrsDic forState:UIControlStateSelected];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [self setLTabBar];
    [self setupCustomTabBarItem];
}

/** 用自定义的tabBar*/
- (void)setLTabBar{
    LTabBar *tabBar = [[LTabBar alloc]init];
//    tabBar.delegate = self;
    /** 通过KVC来替换自定义的tabBar*/
    [self setValue:tabBar forKey:@"tabBar"];
}

/** 自定义tabBarItem*/
- (void)setupCustomTabBarItem{
    [self setupChildViewController:[[LEssenceViewController alloc]init] title:@"精华" imageStr:@"tabBar_essence_icon" selectedImageStr:@"tabBar_essence_click_icon"];
    [self setupChildViewController:[[LNewViewController alloc]init] title:@"新帖" imageStr:@"tabBar_new_icon" selectedImageStr:@"tabBar_new_click_icon"];
    [self setupChildViewController:[[LFollowViewController alloc]init] title:@"关注" imageStr:@"tabBar_friendTrends_icon" selectedImageStr:@"tabBar_friendTrends_click_icon"];
    [self setupChildViewController:[[LMeViewController alloc]init] title:@"我的" imageStr:@"tabBar_me_icon" selectedImageStr:@"tabBar_me_click_icon"];
}


/** 初始化自控制器*/
- (void)setupChildViewController:(UIViewController *)viewController title:(NSString *)title imageStr:(NSString *)imageStr selectedImageStr:(NSString *)selectedImageStr{
    
    /** 设置导航栏标题*/
    viewController.navigationItem.title = title;
    /** 设置标签标题*/
    viewController.tabBarItem.title = title;
    /** 设置标签未点击的图片*/
    viewController.tabBarItem.image = [UIImage imageNamed:imageStr];
    /** 设置标签点击的图片*/
    viewController.tabBarItem.selectedImage = [UIImage imageNamed:selectedImageStr];
    
    /** 设置ViewController背景的随机颜色*/
//    viewController.view.backgroundColor = [UIColor colorWithRed:arc4random_uniform(100)/100.f green:arc4random_uniform(100)/100.f blue:arc4random_uniform(100)/100.f alpha:1.f];
    
    LNavigationController *nav = [[LNavigationController alloc]initWithRootViewController:viewController];
    [self addChildViewController:nav];
}


#pragma mark - system
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
