//
//  LTabBarController.h
//  百思不得姐
//
//  Created by Jimmy_Lee on 2016/12/16.
//  Copyright © 2016年 jimmy_lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LTabBarController : UITabBarController

@end
